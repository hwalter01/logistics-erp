package com.logistics.masterdataservice.dto.request.searchrequest;

import com.logistics.masterdataservice.domain.enums.TrailerStatus;
import com.logistics.masterdataservice.domain.enums.TrailerType;

public record TrailerSearchRequest(
        String trailerNumber,
        String licensePlate,
        TrailerType trailerType,
        TrailerStatus status
) {
}
