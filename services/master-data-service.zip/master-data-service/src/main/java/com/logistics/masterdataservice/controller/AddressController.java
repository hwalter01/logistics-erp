package com.logistics.masterdataservice.controller;

import com.logistics.masterdataservice.dto.PagedResponse;
import com.logistics.masterdataservice.dto.request.AddressRequest;
import com.logistics.masterdataservice.dto.response.AddressResponse;
import com.logistics.masterdataservice.service.AddressService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/addresses")
@RequiredArgsConstructor
public class AddressController {

    private final AddressService addressService;

    @PostMapping
    public AddressResponse create(@Valid @RequestBody AddressRequest request) {
        return addressService.create(request);
    }

    @GetMapping("/{addressId}")
    public AddressResponse getById(@PathVariable UUID addressId) {
        return addressService.getById(addressId);
    }

    @GetMapping
    public PagedResponse<AddressResponse> getAll(@PageableDefault(size = 20, sort = "postalCode")Pageable pageable) {
        return addressService.getAll(pageable);
    }

    @PutMapping("/{addressId}")
    public AddressResponse update(@PathVariable UUID addressId, @Valid @RequestBody AddressRequest request) {return addressService.update(addressId, request);}

    @DeleteMapping("/{addressId}")
    public AddressResponse deleteById(@PathVariable UUID addressId) {return addressService.deleteById(addressId);}
}