package com.logistics.masterdataservice.domain.enums;

public enum TrailerStatus {
    ACTIVE,
    INACTIVE,
    MAINTENANCE,
    IN_REPAIR
}
