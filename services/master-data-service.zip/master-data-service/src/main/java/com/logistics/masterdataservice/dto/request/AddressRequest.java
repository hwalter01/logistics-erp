package com.logistics.masterdataservice.dto.request;

import jakarta.validation.constraints.NotBlank;

public record AddressRequest(
        @NotBlank String street,
        @NotBlank String houseNumber,
        @NotBlank String postalCode,
        @NotBlank String city,
        @NotBlank String country,
        String additionalLine
) {
}