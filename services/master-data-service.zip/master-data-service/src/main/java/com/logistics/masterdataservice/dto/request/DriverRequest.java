package com.logistics.masterdataservice.dto.request;

import com.logistics.masterdataservice.domain.enums.DriverStatus;
import com.logistics.masterdataservice.domain.enums.EmploymentType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.util.UUID;

public record DriverRequest(

        @NotBlank String driverNumber,
        @NotBlank String firstName,
        @NotBlank String lastName,
        String phone,
        String email,
        @NotBlank String licenseNumber,
        @NotNull EmploymentType employmentType,
        @NotNull DriverStatus status,
        UUID addressId
) {
}
