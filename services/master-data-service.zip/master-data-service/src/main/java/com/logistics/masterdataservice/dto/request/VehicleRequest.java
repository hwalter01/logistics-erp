package com.logistics.masterdataservice.dto.request;

import com.logistics.masterdataservice.domain.enums.VehicleStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;


public record VehicleRequest(

        @NotBlank String vehicleNumber,
        @NotBlank String licensePlate,
        String vin,
        String brand,
        String model,
        @NotNull VehicleStatus status,
        String notes
) {
}
