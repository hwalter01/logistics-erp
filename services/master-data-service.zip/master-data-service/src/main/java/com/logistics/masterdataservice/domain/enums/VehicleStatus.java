package com.logistics.masterdataservice.domain.enums;

public enum VehicleStatus {
    ACTIVE,
    INACTIVE,
    MAINTENANCE,
    IN_REPAIR
}
