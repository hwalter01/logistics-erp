package com.logistics.masterdataservice.controller;

import com.logistics.masterdataservice.domain.enums.DriverStatus;
import com.logistics.masterdataservice.domain.enums.EmploymentType;
import com.logistics.masterdataservice.domain.enums.TrailerStatus;
import com.logistics.masterdataservice.domain.enums.TrailerType;
import com.logistics.masterdataservice.dto.PagedResponse;
import com.logistics.masterdataservice.dto.request.TrailerRequest;
import com.logistics.masterdataservice.dto.request.searchrequest.DriverSearchRequest;
import com.logistics.masterdataservice.dto.request.searchrequest.TrailerSearchRequest;
import com.logistics.masterdataservice.dto.response.DriverResponse;
import com.logistics.masterdataservice.dto.response.TrailerResponse;
import com.logistics.masterdataservice.service.TrailerService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/trailers")
@RequiredArgsConstructor
public class TrailerController {
    private final TrailerService trailerService;

    @PostMapping
    public TrailerResponse create(@Valid @RequestBody TrailerRequest request){
        return trailerService.create(request);
    }

    @GetMapping("/{trailerId}")
    public TrailerResponse getById(@PathVariable UUID trailerId){
        return trailerService.getById(trailerId);
    }

    @GetMapping
    public PagedResponse<TrailerResponse> search(
            @RequestParam(required = false) String trailerNumber,
            @RequestParam(required = false) String licensePlate,
            @RequestParam(required = false) TrailerType trailerType,
            @RequestParam(required = false) TrailerStatus status,

            @PageableDefault(size = 20, sort = "trailerNumber") Pageable pageable
    ) {
        TrailerSearchRequest request = new TrailerSearchRequest(
                trailerNumber,
                licensePlate,
                trailerType,
                status
        );

        return trailerService.search(request, pageable);
    }

    @PutMapping("/{trailerId}")
    public TrailerResponse update(@PathVariable UUID trailerId, @Valid @RequestBody TrailerRequest request){return trailerService.update(trailerId, request);}

    @DeleteMapping("/{trailerId}")
    public TrailerResponse deleteById(@PathVariable UUID trailerId){return trailerService.deleteById(trailerId);}
}
