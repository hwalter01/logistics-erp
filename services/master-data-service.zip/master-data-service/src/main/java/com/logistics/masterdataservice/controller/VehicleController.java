package com.logistics.masterdataservice.controller;

import com.logistics.masterdataservice.domain.enums.DriverStatus;
import com.logistics.masterdataservice.domain.enums.EmploymentType;
import com.logistics.masterdataservice.domain.enums.TrailerType;
import com.logistics.masterdataservice.domain.enums.VehicleStatus;
import com.logistics.masterdataservice.dto.PagedResponse;
import com.logistics.masterdataservice.dto.request.VehicleRequest;
import com.logistics.masterdataservice.dto.request.searchrequest.DriverSearchRequest;
import com.logistics.masterdataservice.dto.request.searchrequest.VehicleSearchRequest;
import com.logistics.masterdataservice.dto.response.DriverResponse;
import com.logistics.masterdataservice.dto.response.VehicleResponse;
import com.logistics.masterdataservice.service.VehicleService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/vehicles")
@RequiredArgsConstructor
public class VehicleController {

    private final VehicleService vehicleService;

    @PostMapping
    public VehicleResponse create(@Valid @RequestBody VehicleRequest request) {
        return vehicleService.create(request);
    }

    @GetMapping("/{vehicleId}")
    public VehicleResponse getById(@PathVariable UUID vehicleId) {
        return vehicleService.getById(vehicleId);
    }

    @GetMapping
    public PagedResponse<VehicleResponse> search(
            @RequestParam(required = false) String vehicleNumber,
            @RequestParam(required = false) String licensePlate,
            @RequestParam(required = false) String brand,
            @RequestParam(required = false) String model,
            @RequestParam(required = false) VehicleStatus status,
            @PageableDefault(size = 20, sort = "vehicleNumber") Pageable pageable
    ) {
        VehicleSearchRequest request = new VehicleSearchRequest(
                vehicleNumber,
                licensePlate,
                brand,
                model,
                status
        );

        return vehicleService.search(request, pageable);
    }

    @DeleteMapping("/{vehicleId}")
    public VehicleResponse deleteById(@PathVariable UUID vehicleId) {return vehicleService.deleteById(vehicleId);}
}
