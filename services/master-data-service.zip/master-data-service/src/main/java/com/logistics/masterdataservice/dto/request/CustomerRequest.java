package com.logistics.masterdataservice.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.util.UUID;

public record CustomerRequest (

    @NotBlank String customerNumber,
    @NotBlank String name,
    String vatNumber,
    String contactEmail,
    String contactPhone,
    String notes,
    @NotNull boolean podRequired,
    @NotNull UUID addressId

){

}
