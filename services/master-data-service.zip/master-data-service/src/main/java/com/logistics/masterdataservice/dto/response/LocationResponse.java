package com.logistics.masterdataservice.dto.response;

import java.util.UUID;

public record LocationResponse(
        UUID locationId,
        UUID customerId,
        UUID addressId,
        String name,
        String contactPerson,
        String contactPhone,
        String contactEmail,
        String siteInstructions
) {
}
