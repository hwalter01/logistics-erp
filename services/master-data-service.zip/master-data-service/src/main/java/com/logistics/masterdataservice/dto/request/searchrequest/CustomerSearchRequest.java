package com.logistics.masterdataservice.dto.request.searchrequest;

public record CustomerSearchRequest(
        String customerNumber,
        String vatNumber,
        String name,
        Boolean podRequired
) {
}
