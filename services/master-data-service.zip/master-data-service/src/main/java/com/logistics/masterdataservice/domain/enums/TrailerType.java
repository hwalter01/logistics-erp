package com.logistics.masterdataservice.domain.enums;

public enum TrailerType {
    CURTAINSIDER,
    REEFER,
    FLATBED,
    TANK,
    BOX
}
