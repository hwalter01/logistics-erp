package com.logistics.masterdataservice.dto.request.searchrequest;

import com.logistics.masterdataservice.domain.enums.VehicleStatus;

public record VehicleSearchRequest(
        String vehicleNumber,
        String licensePlate,
        String brand,
        String model,
        VehicleStatus status
) {
}
