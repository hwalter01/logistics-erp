package com.logistics.masterdataservice.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.util.UUID;

public record LocationRequest(
        @NotNull UUID customerId,
        @NotNull UUID addressId,
        @NotBlank String name,
        String contactPerson,
        String contactPhone,
        String contactEmail,
        String siteInstructions
) {
}
