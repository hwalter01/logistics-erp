package com.logistics.masterdataservice.dto.response;

import java.util.UUID;

public record CustomerResponse(

    UUID customerId,

    String customerNumber,
    String name,
    String vatNumber,
    String contactEmail,
    String contactPhone,
    String notes,
    boolean podRequired,
    UUID addressId

){

}
