package com.logistics.masterdataservice.dto.response;

import com.logistics.masterdataservice.domain.enums.VehicleStatus;

import java.util.UUID;

public record VehicleResponse (

        UUID vehicleId,

        String vehicleNumber,
        String licensePlate,
        String vin,
        String brand,
        String model,
        VehicleStatus status,
        String notes
) {
}
