package com.logistics.masterdataservice.dto.request;

import com.logistics.masterdataservice.domain.enums.TrailerStatus;
import com.logistics.masterdataservice.domain.enums.TrailerType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record TrailerRequest(

        @NotBlank String trailerNumber,
        @NotBlank String licensePlate,
        TrailerType trailerType,
        @NotNull TrailerStatus status,
        String notes
) {
}
