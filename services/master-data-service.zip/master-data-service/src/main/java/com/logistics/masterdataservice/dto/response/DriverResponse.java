package com.logistics.masterdataservice.dto.response;

import com.logistics.masterdataservice.domain.enums.DriverStatus;
import com.logistics.masterdataservice.domain.enums.EmploymentType;

import java.util.UUID;

public record DriverResponse(
        UUID driverId,

        String driverNumber,
        String firstName,
        String lastName,
        String phone,
        String email,
        String licenseNumber,
        EmploymentType employmentType,
        DriverStatus status,
        UUID addressId
) {
}
