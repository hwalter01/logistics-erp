package com.logistics.masterdataservice.dto.request.searchrequest;

import com.logistics.masterdataservice.domain.enums.DriverStatus;
import com.logistics.masterdataservice.domain.enums.EmploymentType;

public record DriverSearchRequest(
        String driverNumber,
        String firstName,
        String lastName,
        DriverStatus status,
        EmploymentType employmentType
) {
}
