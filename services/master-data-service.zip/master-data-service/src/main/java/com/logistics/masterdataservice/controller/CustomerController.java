package com.logistics.masterdataservice.controller;

import com.logistics.masterdataservice.dto.PagedResponse;
import com.logistics.masterdataservice.dto.request.CustomerRequest;
import com.logistics.masterdataservice.dto.request.searchrequest.CustomerSearchRequest;
import com.logistics.masterdataservice.dto.response.CustomerResponse;
import com.logistics.masterdataservice.service.CustomerService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/customers")
@RequiredArgsConstructor
public class CustomerController {

    private final CustomerService customerService;

    @PostMapping
    public CustomerResponse create(@Valid @RequestBody CustomerRequest request){
        return customerService.create(request);
    }

    @GetMapping("/{customerId}")
    public CustomerResponse getById(@PathVariable UUID customerId) {
        return customerService.getById(customerId);
    }

    @GetMapping
    public PagedResponse<CustomerResponse> search(
            @RequestParam(required = false) String customerNumber,
            @RequestParam(required = false) String vatNumber,
            @RequestParam(required = false) String name,
            @RequestParam(required = false) Boolean podRequired,
            @PageableDefault(size = 20, sort = "customerNumber") Pageable pageable
    ) {
        CustomerSearchRequest request = new CustomerSearchRequest(
                customerNumber,
                vatNumber,
                name,
                podRequired
        );

        return customerService.search(request, pageable);
    }

    @PutMapping("/{customerId}")
    public CustomerResponse update(@PathVariable UUID customerId,@Valid @RequestBody CustomerRequest request){return customerService.update(customerId, request);}

    @DeleteMapping("/{customerId}")
    public CustomerResponse deleteById(@PathVariable UUID customerId){return customerService.deleteById(customerId);}
}
