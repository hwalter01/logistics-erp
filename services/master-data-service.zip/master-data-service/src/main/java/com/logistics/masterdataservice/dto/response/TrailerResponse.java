package com.logistics.masterdataservice.dto.response;

import com.logistics.masterdataservice.domain.enums.TrailerStatus;
import com.logistics.masterdataservice.domain.enums.TrailerType;

import java.util.UUID;

public record TrailerResponse(

        UUID trailerId,

        String trailerNumber,
        String licensePlate,
        TrailerType trailerType,
        TrailerStatus status,
        String notes
) {
}
