package com.logistics.masterdataservice.domain.enums;

public enum EmploymentType {
    EMPLOYEE,
    SUBCONTRACTOR,
    CONTRACTOR
}
