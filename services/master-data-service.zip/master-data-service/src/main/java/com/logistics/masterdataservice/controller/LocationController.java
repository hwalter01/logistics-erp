package com.logistics.masterdataservice.controller;

import com.logistics.masterdataservice.dto.PagedResponse;
import com.logistics.masterdataservice.dto.request.LocationRequest;
import com.logistics.masterdataservice.dto.request.searchrequest.CustomerSearchRequest;
import com.logistics.masterdataservice.dto.request.searchrequest.LocationSearchRequest;
import com.logistics.masterdataservice.dto.response.CustomerResponse;
import com.logistics.masterdataservice.dto.response.LocationResponse;
import com.logistics.masterdataservice.service.LocationService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/locations")
@RequiredArgsConstructor
public class LocationController {

    private final LocationService locationService;

    @PostMapping
    public LocationResponse create(@Valid @RequestBody LocationRequest request) {
        return locationService.create(request);
    }

    @GetMapping("/{locationId}")
    public LocationResponse findById(@PathVariable UUID locationId) {
        return locationService.getById(locationId);
    }

    @GetMapping
    public PagedResponse<LocationResponse> search(
            @RequestParam(required = false) UUID customerId,
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String city,
            @PageableDefault(size = 20, sort = "name") Pageable pageable
    ) {
        LocationSearchRequest request = new LocationSearchRequest(
                customerId,
                name,
                city
        );

        return locationService.search(request, pageable);
    }

    @PutMapping("/{locationId}")
    public LocationResponse update(@PathVariable UUID locationId, @Valid @RequestBody LocationRequest request){return locationService.update(locationId,request);}

    @DeleteMapping("/{locationId}")
    public LocationResponse deleteById(@PathVariable UUID locationId) {return locationService.deleteById(locationId);}
}
