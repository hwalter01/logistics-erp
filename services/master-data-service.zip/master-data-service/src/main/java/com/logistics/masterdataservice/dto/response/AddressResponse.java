package com.logistics.masterdataservice.dto.response;

import java.util.UUID;

public record AddressResponse(
        UUID addressId,
        String street,
        String houseNumber,
        String postalCode,
        String city,
        String country,
        String additionalLine
) {
}