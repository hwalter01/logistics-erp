package com.logistics.masterdataservice.controller;

import com.logistics.masterdataservice.domain.enums.DriverStatus;
import com.logistics.masterdataservice.domain.enums.EmploymentType;
import com.logistics.masterdataservice.dto.PagedResponse;
import com.logistics.masterdataservice.dto.request.DriverRequest;
import com.logistics.masterdataservice.dto.request.searchrequest.DriverSearchRequest;
import com.logistics.masterdataservice.dto.response.DriverResponse;
import com.logistics.masterdataservice.service.DriverService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/drivers")
@RequiredArgsConstructor
public class DriverController {

    private final DriverService driverService;

    @PostMapping
    public DriverResponse create(@Valid @RequestBody DriverRequest request){
        return driverService.create(request);
    }

    @GetMapping("/{driverId}")
    public DriverResponse getById(@PathVariable UUID driverId){
        return driverService.getById(driverId);
    }

    @GetMapping
    public PagedResponse<DriverResponse> search(
            @RequestParam(required = false) String driverNumber,
            @RequestParam(required = false) String firstName,
            @RequestParam(required = false) String lastName,
            @RequestParam(required = false) EmploymentType employmentType,
            @RequestParam(required = false) DriverStatus status,
            @PageableDefault(size = 20, sort = "driverNumber") Pageable pageable
    ) {
        DriverSearchRequest request = new DriverSearchRequest(
                driverNumber,
                firstName,
                lastName,
                status,
                employmentType
        );

        return driverService.search(request, pageable);
    }

    @PutMapping("/{driverId}")
    public DriverResponse update(@PathVariable UUID driverId, @Valid @RequestBody DriverRequest request){return driverService.update(driverId, request);}

    @DeleteMapping("/{driverId}")
    public DriverResponse deleteById(@PathVariable UUID driverId){return driverService.deleteById(driverId);}
}
