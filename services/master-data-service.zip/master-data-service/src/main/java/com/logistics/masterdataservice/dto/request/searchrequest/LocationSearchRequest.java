package com.logistics.masterdataservice.dto.request.searchrequest;

import java.util.UUID;

public record LocationSearchRequest(
        UUID customerId,
        String name,
        String city
) {
}
